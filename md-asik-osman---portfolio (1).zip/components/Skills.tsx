
import React from 'react';
import Section from './Section';
import { motion } from 'framer-motion';
import { 
  Users, 
  MessageSquare, 
  Briefcase, 
  Calculator, 
  Cloud, 
  FileSpreadsheet, 
  TrendingUp, 
  CheckCircle2,
  Award
} from 'lucide-react';

interface SkillsProps {
  skills: string[];
}

const getIconForSkill = (skill: string) => {
  const s = skill.toLowerCase();
  if (s.includes('leader') || s.includes('team')) return <Users size={20} />;
  if (s.includes('debate') || s.includes('speak') || s.includes('communicat')) return <MessageSquare size={20} />;
  if (s.includes('bookkeep') || s.includes('audit') || s.includes('tax')) return <Calculator size={20} />;
  if (s.includes('virtual') || s.includes('cloud') || s.includes('remote')) return <Cloud size={20} />;
  if (s.includes('analy') || s.includes('report') || s.includes('growth')) return <TrendingUp size={20} />;
  if (s.includes('excel') || s.includes('sheet') || s.includes('data')) return <FileSpreadsheet size={20} />;
  if (s.includes('account') || s.includes('manage') || s.includes('business')) return <Briefcase size={20} />;
  if (s.includes('certif') || s.includes('award')) return <Award size={20} />;
  return <CheckCircle2 size={20} />;
};

const Skills: React.FC<SkillsProps> = ({ skills }) => {
  return (
    <Section id="skills" className="bg-white">
      <div className="flex flex-col md:flex-row gap-12">
        <div className="md:w-1/3">
          <motion.h2 
            initial={{ opacity: 0, x: -20 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.5 }}
            className="text-3xl font-bold text-slate-900 mb-4 flex items-center gap-3"
          >
             <span className="w-8 h-1 bg-blue-600 block rounded-full"></span>
             Expertise
          </motion.h2>
          <motion.p 
            initial={{ opacity: 0, x: -20 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.5, delay: 0.1 }}
            className="text-slate-600 leading-relaxed"
          >
            I bring a combination of technical accounting knowledge and soft skills to drive efficiency and growth for businesses.
          </motion.p>
        </div>
        <div className="md:w-2/3">
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
            {skills.map((skill, index) => (
              <motion.div
                key={index}
                initial={{ opacity: 0, y: 10 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.4, delay: index * 0.05 }}
                whileHover={{ scale: 1.03, backgroundColor: "#eff6ff" }}
                className="p-4 rounded-xl bg-slate-50 border border-slate-100 shadow-sm transition-colors cursor-default flex items-center gap-3 group"
              >
                <div className="text-blue-600 p-2 bg-blue-50 rounded-lg group-hover:bg-blue-600 group-hover:text-white transition-colors duration-300">
                  <div className="transition-transform duration-300 group-hover:scale-125">
                    {getIconForSkill(skill)}
                  </div>
                </div>
                <h3 className="font-semibold text-slate-800">{skill}</h3>
              </motion.div>
            ))}
          </div>
        </div>
      </div>
    </Section>
  );
};

export default Skills;
