
import React from 'react';
import Section from './Section';
import { FolderGit2, ExternalLink } from 'lucide-react';
import { motion } from 'framer-motion';
import { ProjectItem } from '../types';

interface ProjectsProps {
  projects: ProjectItem[];
}

const Projects: React.FC<ProjectsProps> = ({ projects }) => {
  return (
    <Section id="projects" className="bg-slate-50">
      <div className="text-center mb-12">
         <motion.h2 
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.5 }}
            className="text-3xl font-bold text-slate-900 inline-flex items-center gap-3"
         >
            <FolderGit2 className="text-blue-600" size={32} />
            Featured Projects
         </motion.h2>
         <motion.p 
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.5, delay: 0.1 }}
            className="text-slate-600 mt-4 max-w-2xl mx-auto"
         >
            A selection of professional engagements and case studies demonstrating my accounting and bookkeeping expertise.
         </motion.p>
      </div>
      
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {projects.map((project, index) => (
          <motion.div
            key={project.id || index}
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            whileHover={{ 
              scale: 1.02, 
              y: -5,
            }}
            transition={{ duration: 0.3 }}
            viewport={{ once: true }}
            className="group bg-white rounded-2xl shadow-sm border border-slate-100 cursor-default flex flex-col overflow-hidden hover:shadow-xl hover:shadow-blue-900/5 transition-all"
          >
            {project.image ? (
                <div className="w-full h-48 overflow-hidden relative">
                    <img 
                        src={project.image} 
                        alt={project.title} 
                        className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-105"
                    />
                    <div className="absolute inset-0 bg-gradient-to-t from-black/50 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300" />
                </div>
            ) : null}

            <div className="p-6 flex flex-col flex-grow">
                {!project.image && (
                    <div className="mb-4">
                        <div className="p-3 bg-blue-50 rounded-lg text-blue-600 inline-block">
                            <FolderGit2 size={24} />
                        </div>
                    </div>
                )}
                
                <h3 className="text-lg font-bold text-slate-900 mb-2 group-hover:text-blue-600 transition-colors">
                    {project.title}
                </h3>
                <p className="text-slate-600 text-sm leading-relaxed mb-6 flex-grow">
                    {project.description}
                </p>

                {project.link && (
                    <a 
                        href={project.link} 
                        target="_blank" 
                        rel="noreferrer"
                        className="inline-flex items-center justify-center gap-2 w-full px-4 py-3 bg-slate-50 hover:bg-blue-600 text-slate-700 hover:text-white rounded-xl text-sm font-semibold transition-all duration-300 group/btn mt-auto border border-slate-100 hover:border-transparent hover:shadow-lg hover:shadow-blue-500/20"
                    >
                        View Live Demo
                        <ExternalLink size={16} className="group-hover/btn:translate-x-0.5 group-hover/btn:-translate-y-0.5 transition-transform" />
                    </a>
                )}
            </div>
          </motion.div>
        ))}
      </div>
    </Section>
  );
};

export default Projects;
