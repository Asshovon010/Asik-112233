
import React, { useState, useEffect } from 'react';
import { ResumeData, ProjectItem, CertificationItem, EducationItem, ServiceItem, TestimonialItem } from '../types';
import { Save, X, Plus, Trash2, Lock, User, BookOpen, Award, GraduationCap, FolderGit2, Check, LogOut, Briefcase, Quote, Sparkles, Upload, Image as ImageIcon, Mail, Phone, MapPin, Linkedin, Search, Shield, Key, Eye, EyeOff, Layout, StickyNote, CheckSquare, Loader2 } from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';
import { getAdminCredentials, saveAdminCredentials, getAllNotes, saveNote, deleteNote, getAllTasks, saveTask, deleteTask, NoteItem, TaskItem } from '../services/db';

// --- Constants & Types ---

const TABS = [
  { id: 'profile', icon: User, label: 'Profile' },
  { id: 'contact', icon: Mail, label: 'Contact Info' },
  { id: 'services', icon: Briefcase, label: 'Services' },
  { id: 'testimonials', icon: Quote, label: 'Stories' },
  { id: 'skills', icon: BookOpen, label: 'Skills' },
  { id: 'certifications', icon: Award, label: 'Certificates' },
  { id: 'education', icon: GraduationCap, label: 'Education' },
  { id: 'projects', icon: FolderGit2, label: 'Projects' },
  { id: 'workspace', icon: Layout, label: 'Workspace' },
  { id: 'security', icon: Shield, label: 'Security' },
] as const;

type TabId = typeof TABS[number]['id'];

interface AdminPanelProps {
  initialData: ResumeData;
  onSave: (data: ResumeData) => void;
  onClose: () => void;
}

// --- Main Component ---

const AdminPanel: React.FC<AdminPanelProps> = ({ initialData, onSave, onClose }) => {
  const [data, setData] = useState<ResumeData>(initialData);
  const [activeTab, setActiveTab] = useState<TabId>('profile');
  const [isAuthenticated, setIsAuthenticated] = useState(false);
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');
  const [uploadError, setUploadError] = useState<string | null>(null);
  const [skillFilter, setSkillFilter] = useState('');
  const [newSkillInput, setNewSkillInput] = useState('');
  const [isSaving, setIsSaving] = useState(false);
  const [saveSuccess, setSaveSuccess] = useState(false);
  const [dbCredentials, setDbCredentials] = useState({ username: 'admin', password: 'admin123' });

  // Load credentials from DB
  useEffect(() => {
    const loadCreds = async () => {
        try {
            const creds = await getAdminCredentials();
            if (creds) {
                setDbCredentials(creds);
            } else {
                // Check localStorage fallback
                const local = localStorage.getItem('portfolio_admin_creds');
                if (local) {
                    const parsed = JSON.parse(local);
                    setDbCredentials(parsed);
                    await saveAdminCredentials(parsed);
                    localStorage.removeItem('portfolio_admin_creds');
                }
            }
        } catch (e) {
            console.error(e);
        }
    };
    loadCreds();
  }, []);

  // Clear upload errors when switching tabs
  useEffect(() => {
    setUploadError(null);
    setSkillFilter('');
    setNewSkillInput('');
  }, [activeTab]);

  const handleLogin = (e: React.FormEvent) => {
    e.preventDefault();
    if (username === dbCredentials.username && password === dbCredentials.password) {
      setIsAuthenticated(true);
      setError('');
    } else {
      setError('Invalid username or password');
      const form = document.getElementById('login-form');
      form?.classList.add('animate-shake');
      setTimeout(() => form?.classList.remove('animate-shake'), 500);
    }
  };

  const handleSave = () => {
    setIsSaving(true);
    setTimeout(() => {
        try {
            onSave(data);
            setIsSaving(false);
            setSaveSuccess(true);
            setTimeout(() => setSaveSuccess(false), 2000);
        } catch (err) {
            console.error(err);
            setIsSaving(false);
        }
    }, 800);
  };

  const handleUpdateCredentials = async (newCreds: { username: string; password: string }) => {
      setDbCredentials(newCreds);
      await saveAdminCredentials(newCreds);
      // Update current session username if it matches
      if (username === dbCredentials.username) {
          setUsername(newCreds.username);
      }
  };

  const handleImageUpload = (e: React.ChangeEvent<HTMLInputElement>, callback: (base64: string) => void) => {
    const file = e.target.files?.[0];
    if (file) {
      // Validate file type strictly (JPG, PNG, GIF)
      const validTypes = ['image/jpeg', 'image/png', 'image/gif'];
      if (!validTypes.includes(file.type)) {
        setUploadError('Invalid file type. Please upload a JPG, PNG, or GIF image.');
        e.target.value = ''; // Reset input
        return;
      }
      
      // Validate file size (max 500KB)
      if (file.size > 500 * 1024) {
          setUploadError('Image too large. Please upload an image smaller than 500KB.');
          e.target.value = '';
          return;
      }

      setUploadError(null); // Clear previous errors

      const reader = new FileReader();
      reader.onloadend = () => {
        if (typeof reader.result === 'string') {
          callback(reader.result);
        }
      };
      reader.readAsDataURL(file);
    }
  };

  if (!isAuthenticated) {
    return (
      <LoginView 
        username={username} 
        setUsername={setUsername} 
        password={password} 
        setPassword={setPassword} 
        handleLogin={handleLogin} 
        error={error} 
        onClose={onClose} 
      />
    );
  }

  const renderTabContent = () => {
    switch (activeTab) {
      case 'profile':
        return (
            <div className="space-y-6">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <AnimatedField delay={0.05} label="Full Name" value={data.name} onChange={(v) => setData({...data, name: v})} />
                    <AnimatedField delay={0.1} label="Job Title" value={data.title} onChange={(v) => setData({...data, title: v})} fullWidth />
                </div>

                <motion.div 
                    initial={{ opacity: 0, y: 10 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ delay: 0.15 }}
                    className="space-y-4"
                >
                    <div>
                        <label className="block text-xs font-bold uppercase tracking-wider text-slate-400 mb-1.5 ml-1">About Me Summary</label>
                        <textarea 
                            value={data.summary || ''} 
                            onChange={(e) => setData({...data, summary: e.target.value})}
                            rows={6}
                            className="w-full px-4 py-3 bg-slate-50 border border-slate-200 rounded-xl focus:ring-2 focus:ring-blue-500/20 focus:border-blue-500 outline-none transition-all resize-y"
                            placeholder="Write a brief professional summary about yourself..."
                        />
                    </div>
                </motion.div>

                {/* Profile Image Upload */}
                <motion.div 
                    initial={{ opacity: 0, y: 10 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ delay: 0.2 }}
                    className="p-4 bg-slate-50 border border-slate-200 border-dashed rounded-xl mt-2"
                >
                    <div className="flex flex-col md:flex-row items-center justify-between gap-4">
                        <div>
                            <span className="block text-sm font-semibold text-slate-700 mb-1">Profile Picture</span>
                            <span className="text-xs text-slate-500">Upload a professional photo for the About section (Max 500KB)</span>
                        </div>
                        <label className="cursor-pointer">
                            <input 
                                type="file" 
                                accept=".jpg, .jpeg, .png, .gif" 
                                className="hidden" 
                                onChange={(e) => handleImageUpload(e, (base64) => setData({...data, profileImage: base64}))}
                            />
                            <div className="px-4 py-2 bg-blue-100 text-blue-700 hover:bg-blue-200 rounded-lg font-semibold flex items-center gap-2 transition-colors hover:shadow-md">
                                <Upload size={16} /> Choose Image
                            </div>
                        </label>
                    </div>
                    
                    <div className="mt-4 flex justify-center">
                        {data.profileImage ? (
                            <div className="relative inline-block group/preview">
                                <img src={data.profileImage} alt="Profile Preview" className="h-40 w-40 rounded-full border-4 border-white shadow-md object-cover bg-white" />
                                <button 
                                    onClick={() => setData({...data, profileImage: ''})}
                                    className="absolute top-0 right-0 p-1.5 bg-red-500 text-white rounded-full hover:bg-red-600 shadow-md opacity-0 group-hover/preview:opacity-100 transition-opacity"
                                    title="Remove Image"
                                >
                                    <X size={14} />
                                </button>
                            </div>
                        ) : (
                            <div className="h-40 w-40 rounded-full bg-slate-100 border-2 border-slate-200 border-dashed flex items-center justify-center text-slate-400">
                                <User size={40} className="opacity-50" />
                            </div>
                        )}
                    </div>
                    {uploadError && !data.profileImage && (
                        <div className="mt-2 text-center text-sm text-red-500 font-medium">
                            {uploadError}
                        </div>
                    )}
                </motion.div>
            </div>
        );
      case 'contact':
        return (
            <div className="space-y-6">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <motion.div 
                        initial={{ opacity: 0, y: 10 }}
                        animate={{ opacity: 1, y: 0 }}
                        transition={{ delay: 0.1 }}
                        className="col-span-1 md:col-span-2 p-6 bg-slate-50 border border-slate-100 rounded-2xl space-y-4"
                    >
                        <div className="flex items-center gap-3 mb-2">
                            <div className="p-2 bg-white rounded-lg shadow-sm text-blue-600">
                                <Phone size={20} />
                            </div>
                            <label className="text-sm font-bold uppercase tracking-wider text-slate-500">Primary Contact</label>
                        </div>
                        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                            <Field label="Phone Number" value={data.contact.phone} onChange={(v) => setData({...data, contact: {...data.contact, phone: v}})} />
                            <Field label="Email Address" value={data.contact.email} onChange={(v) => setData({...data, contact: {...data.contact, email: v}})} />
                        </div>
                    </motion.div>

                    <motion.div 
                        initial={{ opacity: 0, y: 10 }}
                        animate={{ opacity: 1, y: 0 }}
                        transition={{ delay: 0.2 }}
                        className="col-span-1 md:col-span-2 p-6 bg-slate-50 border border-slate-100 rounded-2xl space-y-4"
                    >
                        <div className="flex items-center gap-3 mb-2">
                            <div className="p-2 bg-white rounded-lg shadow-sm text-blue-600">
                                <MapPin size={20} />
                            </div>
                            <label className="text-sm font-bold uppercase tracking-wider text-slate-500">Location & Social</label>
                        </div>
                        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                            <Field label="Physical Location" value={data.contact.location} onChange={(v) => setData({...data, contact: {...data.contact, location: v}})} />
                            <Field label="LinkedIn (without https://)" value={data.contact.linkedin} onChange={(v) => setData({...data, contact: {...data.contact, linkedin: v}})} />
                        </div>
                    </motion.div>
                </div>
            </div>
        );
      case 'services':
        return (
            <ListEditor 
                items={data.services || []}
                onUpdate={(items) => setData({...data, services: items as ServiceItem[]})}
                renderItem={(item, onChange) => (
                    <div className="space-y-4">
                        <Field label="Service Title" value={item.title} onChange={(v) => onChange({...item, title: v})} fullWidth />
                        <div>
                            <label className="block text-xs font-bold uppercase tracking-wider text-slate-400 mb-1.5">Description</label>
                            <textarea 
                                value={item.description} 
                                onChange={(e) => onChange({...item, description: e.target.value})}
                                rows={3}
                                className="w-full px-4 py-3 bg-slate-50 border border-slate-200 rounded-xl focus:ring-2 focus:ring-blue-500/20 focus:border-blue-500 outline-none transition-all resize-y"
                            />
                        </div>
                    </div>
                )}
                newItem={{ id: Date.now().toString(), title: 'New Service', description: 'Description of the service...' }}
            />
        );
      case 'testimonials':
        return (
            <ListEditor 
                items={data.testimonials || []}
                onUpdate={(items) => setData({...data, testimonials: items as TestimonialItem[]})}
                renderItem={(item, onChange) => (
                    <div className="space-y-4">
                        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                            <Field label="Client Name" value={item.name} onChange={(v) => onChange({...item, name: v})} />
                            <Field label="Role / Company" value={item.role} onChange={(v) => onChange({...item, role: v})} />
                        </div>
                        <div>
                            <label className="block text-xs font-bold uppercase tracking-wider text-slate-400 mb-1.5">Client Quote</label>
                            <textarea 
                                value={item.quote} 
                                onChange={(e) => onChange({...item, quote: e.target.value})}
                                rows={3}
                                className="w-full px-4 py-3 bg-slate-50 border border-slate-200 rounded-xl focus:ring-2 focus:ring-blue-500/20 focus:border-blue-500 outline-none transition-all resize-y"
                            />
                        </div>
                    </div>
                )}
                newItem={{ id: Date.now().toString(), name: 'Client Name', role: 'Company', quote: 'Great service!' }}
            />
        );
      case 'skills':
        const filteredSkills = data.skills.filter(s => s.toLowerCase().includes(skillFilter.toLowerCase()));
        
        const handleAddSkill = () => {
            if (!newSkillInput.trim()) return;
            const newSkills = newSkillInput.split(',')
                .map(s => s.trim())
                .filter(s => s.length > 0 && !data.skills.includes(s));
                
            if (newSkills.length > 0) {
                setData({ ...data, skills: [...data.skills, ...newSkills] });
                setNewSkillInput('');
            } else {
                 setNewSkillInput('');
            }
        };
    
        const handleRemoveSkill = (skillToRemove: string) => {
            setData({ ...data, skills: data.skills.filter(s => s !== skillToRemove) });
        };
        
        return (
            <motion.div
                initial={{ opacity: 0, scale: 0.95 }}
                animate={{ opacity: 1, scale: 1 }}
                transition={{ duration: 0.4 }}
                className="h-full flex flex-col"
            >
                <div className="space-y-6 mb-6">
                   <div className="bg-white p-6 rounded-2xl border border-slate-200 shadow-sm">
                       <label className="block text-xs font-bold uppercase tracking-wider text-slate-400 mb-3">Add New Skills</label>
                       <div className="flex gap-2">
                          <input 
                              type="text" 
                              value={newSkillInput}
                              onChange={(e) => setNewSkillInput(e.target.value)}
                              onKeyDown={(e) => e.key === 'Enter' && handleAddSkill()}
                              placeholder="Type a skill (e.g. 'Financial Analysis') and press Enter" 
                              className="flex-1 px-4 py-3 bg-slate-50 border border-slate-200 rounded-xl focus:ring-2 focus:ring-blue-500/20 focus:border-blue-500 outline-none transition-all"
                          />
                          <button 
                             onClick={handleAddSkill}
                             disabled={!newSkillInput.trim()}
                             className="px-6 py-3 bg-blue-600 text-white font-bold rounded-xl hover:bg-blue-700 disabled:opacity-50 disabled:cursor-not-allowed transition-colors flex items-center gap-2 shadow-lg shadow-blue-500/20"
                          >
                             <Plus size={20} /> <span className="hidden sm:inline">Add</span>
                          </button>
                       </div>
                   </div>
                   
                   <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
                        <div className="relative group/search flex-1 max-w-xs">
                            <Search size={16} className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400 group-focus-within/search:text-blue-500 transition-colors" />
                            <input 
                                type="text" 
                                placeholder="Search existing skills..." 
                                value={skillFilter}
                                onChange={(e) => setSkillFilter(e.target.value)}
                                className="w-full pl-9 pr-4 py-2 bg-white border border-slate-200 rounded-xl text-sm focus:ring-2 focus:ring-blue-500/20 focus:border-blue-500 outline-none transition-all shadow-sm"
                            />
                        </div>
                        <div className="text-xs font-bold uppercase tracking-wider text-slate-400 bg-white px-3 py-1.5 rounded-lg border border-slate-200 shadow-sm">
                            {data.skills.length} Active Skills
                        </div>
                   </div>
                </div>

                <div className="bg-slate-50 border border-slate-100 rounded-2xl p-6 flex-1 overflow-y-auto min-h-[300px]">
                     <div className="flex flex-wrap gap-3">
                        <AnimatePresence>
                            {filteredSkills.map((skill) => (
                                <motion.span 
                                    layout
                                    initial={{ opacity: 0, scale: 0.8 }}
                                    animate={{ opacity: 1, scale: 1 }}
                                    exit={{ opacity: 0, scale: 0.8 }}
                                    key={skill} 
                                    className="pl-4 pr-2 py-2.5 bg-white text-slate-700 font-medium border border-slate-200 rounded-xl shadow-sm flex items-center gap-3 group hover:border-blue-400 hover:shadow-md transition-all select-none"
                                >
                                    {skill}
                                    <button 
                                        onClick={() => handleRemoveSkill(skill)}
                                        className="p-1 text-slate-300 hover:text-red-500 hover:bg-red-50 rounded-lg transition-all"
                                        title="Remove skill"
                                    >
                                        <X size={16} />
                                    </button>
                                </motion.span>
                            ))}
                        </AnimatePresence>
                     </div>
                </div>
            </motion.div>
        );
      case 'certifications':
        return (
            <div className="space-y-4">
                {uploadError && (
                    <motion.div 
                        initial={{ opacity: 0, y: -10 }}
                        animate={{ opacity: 1, y: 0 }}
                        className="p-4 bg-red-50 text-red-600 rounded-xl border border-red-100 flex items-center gap-3 shadow-sm"
                    >
                        <div className="p-1.5 bg-red-100 rounded-full"><X size={14} /></div>
                        <span className="font-medium text-sm">{uploadError}</span>
                    </motion.div>
                )}
                <ListEditor 
                    items={data.certifications}
                    onUpdate={(items) => setData({...data, certifications: items as CertificationItem[]})}
                    renderItem={(item, onChange) => (
                        <div className="space-y-4">
                            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                                <Field label="Certification Title" value={item.title} onChange={(v) => onChange({...item, title: v})} fullWidth />
                                <Field label="Issuing Organization" value={item.issuer} onChange={(v) => onChange({...item, issuer: v})} />
                                <Field label="Year" value={item.year || ''} onChange={(v) => onChange({...item, year: v})} />
                                <Field label="Link URL" value={item.link || ''} onChange={(v) => onChange({...item, link: v})} />
                            </div>
                            
                            <div className="p-4 bg-slate-50 border border-slate-200 border-dashed rounded-xl mt-2">
                                <div className="flex flex-col md:flex-row items-center justify-between gap-4">
                                    <div>
                                        <span className="block text-sm font-semibold text-slate-700 mb-1">Upload Certificate Image</span>
                                        <span className="text-xs text-slate-500">Upload an image file to display when clicking "View Certificate"</span>
                                    </div>
                                    <label className="cursor-pointer">
                                        <input 
                                            type="file" 
                                            accept=".jpg, .jpeg, .png, .gif" 
                                            className="hidden" 
                                            onChange={(e) => handleImageUpload(e, (base64) => onChange({...item, link: base64}))}
                                        />
                                        <div className="px-4 py-2 bg-blue-100 text-blue-700 hover:bg-blue-200 rounded-lg font-semibold flex items-center gap-2 transition-colors hover:shadow-md">
                                            <Upload size={16} /> Choose Image
                                        </div>
                                    </label>
                                </div>
                                
                                <div className="mt-4">
                                    {item.link ? (
                                        item.link.startsWith('data:image') ? (
                                            <div className="relative inline-block group/preview">
                                                <img src={item.link} alt="Preview" className="h-24 w-auto rounded-lg border border-slate-200 shadow-sm object-cover bg-white" />
                                                <button 
                                                    onClick={() => onChange({...item, link: ''})}
                                                    className="absolute -top-2 -right-2 p-1.5 bg-red-500 text-white rounded-full hover:bg-red-600 shadow-md opacity-0 group-hover/preview:opacity-100 transition-opacity"
                                                    title="Remove Image"
                                                >
                                                    <X size={14} />
                                                </button>
                                                <span className="absolute bottom-1 right-1 bg-black/60 text-white text-[10px] px-1.5 py-0.5 rounded backdrop-blur-sm">Base64</span>
                                            </div>
                                        ) : (
                                            <div className="flex items-center gap-3 p-3 bg-white rounded-lg border border-slate-200 text-sm text-slate-600 max-w-full">
                                                <div className="p-2 bg-slate-100 rounded text-slate-400">
                                                    <Award size={16} />
                                                </div>
                                                <div className="truncate flex-1 font-mono text-xs">{item.link}</div>
                                                <button 
                                                    onClick={() => onChange({...item, link: ''})}
                                                    className="p-1 hover:bg-red-50 hover:text-red-500 rounded transition-colors"
                                                    title="Clear Link"
                                                >
                                                    <X size={16} />
                                                </button>
                                            </div>
                                        )
                                    ) : (
                                        <div className="flex items-center justify-center h-24 bg-slate-100/50 rounded-lg border-2 border-slate-100 border-dashed text-slate-400">
                                            <div className="flex flex-col items-center gap-2">
                                                <div className="p-2 bg-slate-100 rounded-full">
                                                    <ImageIcon size={20} className="opacity-50" />
                                                </div>
                                                <span className="text-xs font-medium opacity-60">No image selected</span>
                                            </div>
                                        </div>
                                    )}
                                </div>
                            </div>
                        </div>
                    )}
                    newItem={{ id: Date.now().toString(), title: 'New Certification', issuer: 'Issuer', year: new Date().getFullYear().toString(), link: '' }}
                />
            </div>
        );
      case 'education':
        return (
             <ListEditor 
                items={data.education}
                onUpdate={(items) => setData({...data, education: items as EducationItem[]})}
                renderItem={(item, onChange) => (
                    <div className="space-y-4">
                        <Field label="Institution Name" value={item.institution} onChange={(v) => onChange({...item, institution: v})} fullWidth />
                        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                            <Field label="Degree / Certificate" value={item.degree} onChange={(v) => onChange({...item, degree: v})} />
                            <Field label="Years Attended" value={item.year || ''} onChange={(v) => onChange({...item, year: v})} />
                        </div>
                    </div>
                )}
                newItem={{ id: Date.now().toString(), institution: 'New Institution', degree: 'Degree Name', year: '2020-2024' }}
            />
        );
      case 'projects':
        return (
             <div className="space-y-6">
                <div className="mb-2">
                     <h3 className="text-lg font-semibold text-slate-800 mb-1 flex items-center gap-2">
                        <FolderGit2 size={18} className="text-blue-500" /> 
                        Projects
                    </h3>
                    <p className="text-sm text-slate-500">
                        Manage your portfolio projects. Uploading a cover image will replace the default icon on the public site.
                    </p>
                </div>

                {uploadError && (
                    <motion.div 
                        initial={{ opacity: 0, y: -10 }}
                        animate={{ opacity: 1, y: 0 }}
                        className="p-4 bg-red-50 text-red-600 rounded-xl border border-red-100 flex items-center gap-3 shadow-sm"
                    >
                        <div className="p-1.5 bg-red-100 rounded-full"><X size={14} /></div>
                        <span className="font-medium text-sm">{uploadError}</span>
                    </motion.div>
                )}
                <ListEditor 
                    items={data.projects}
                    onUpdate={(items) => setData({...data, projects: items as ProjectItem[]})}
                    renderItem={(item, onChange) => (
                        <div className="space-y-4">
                            <Field label="Project Title" value={item.title} onChange={(v) => onChange({...item, title: v})} fullWidth />
                            
                            <div className="p-4 bg-slate-50 border border-slate-200 border-dashed rounded-xl mt-2">
                                <div className="flex flex-col md:flex-row items-center justify-between gap-4">
                                    <div>
                                        <span className="block text-sm font-semibold text-slate-700 mb-1">Project Image</span>
                                        <span className="text-xs text-slate-500">Upload a cover image (replaces default icon)</span>
                                    </div>
                                    <label className="cursor-pointer">
                                        <input 
                                            type="file" 
                                            accept=".jpg, .jpeg, .png, .gif" 
                                            className="hidden" 
                                            onChange={(e) => handleImageUpload(e, (base64) => onChange({...item, image: base64}))}
                                        />
                                        <div className="px-4 py-2 bg-blue-100 text-blue-700 hover:bg-blue-200 rounded-lg font-semibold flex items-center gap-2 transition-colors hover:shadow-md">
                                            <Upload size={16} /> Choose Image
                                        </div>
                                    </label>
                                </div>
                                
                                <div className="mt-4">
                                    {item.image ? (
                                        <div className="relative inline-block group/preview">
                                            <img src={item.image} alt="Preview" className="h-32 w-auto rounded-lg border border-slate-200 shadow-sm object-cover bg-white" />
                                            <button 
                                                onClick={() => onChange({...item, image: ''})}
                                                className="absolute -top-2 -right-2 p-1.5 bg-red-500 text-white rounded-full hover:bg-red-600 shadow-md opacity-0 group-hover/preview:opacity-100 transition-opacity"
                                                title="Remove Image"
                                            >
                                                <X size={14} />
                                            </button>
                                            <span className="absolute bottom-1 right-1 bg-black/60 text-white text-[10px] px-1.5 py-0.5 rounded backdrop-blur-sm">Base64</span>
                                        </div>
                                    ) : (
                                        <div className="flex items-center justify-center h-24 bg-slate-100/50 rounded-lg border-2 border-slate-100 border-dashed text-slate-400">
                                            <div className="flex flex-col items-center gap-2">
                                                <div className="p-2 bg-slate-100 rounded-full">
                                                    <ImageIcon size={20} className="opacity-50" />
                                                </div>
                                                <span className="text-xs font-medium opacity-60">No image selected</span>
                                            </div>
                                        </div>
                                    )}
                                </div>
                            </div>

                            <Field label="Project Link (Optional)" value={item.link || ''} onChange={(v) => onChange({...item, link: v})} fullWidth />
                            <div>
                                <label className="block text-xs font-bold uppercase tracking-wider text-slate-400 mb-1.5">Description</label>
                                <textarea 
                                    value={item.description} 
                                    onChange={(e) => onChange({...item, description: e.target.value})}
                                    rows={3}
                                    className="w-full px-4 py-3 bg-slate-50 border border-slate-200 rounded-xl focus:ring-2 focus:ring-blue-500/20 focus:border-blue-500 outline-none transition-all resize-y"
                                />
                            </div>
                        </div>
                    )}
                    newItem={{ id: Date.now().toString(), title: 'New Project', description: 'Project description...', link: '', image: '' }}
                />
            </div>
        );
      case 'workspace':
        return <WorkspaceTab />;
      case 'security':
        return (
            <SecuritySettings 
                currentCredentials={dbCredentials} 
                onUpdate={handleUpdateCredentials} 
            />
        );
      default:
        return null;
    }
  };

  return (
    <motion.div 
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        exit={{ opacity: 0 }}
        className="fixed inset-0 z-[100] flex flex-col md:flex-row h-screen w-screen overflow-hidden bg-slate-100"
    >
      <Sidebar 
        activeTab={activeTab} 
        setActiveTab={setActiveTab} 
        onClose={onClose} 
        handleSave={handleSave} 
        isSaving={isSaving} 
        saveSuccess={saveSuccess} 
      />

      {/* Main Content */}
      <div className="flex-1 overflow-y-auto bg-slate-50/50 relative">
         <div className="max-w-5xl mx-auto p-4 md:p-10 mb-20 md:mb-0 min-h-full">
            <motion.div
                key={activeTab}
                initial={{ opacity: 0, y: -10 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.3 }}
                className="mb-8 flex justify-between items-end"
            >
                <div>
                    <h1 className="text-3xl font-bold text-slate-900 flex items-center gap-3">
                        {TABS.find(t => t.id === activeTab)?.label}
                    </h1>
                    <p className="text-slate-500 mt-1">Manage your {TABS.find(t => t.id === activeTab)?.label.toLowerCase()} details</p>
                </div>
                <div className="hidden md:block px-4 py-1.5 bg-blue-50 text-blue-600 text-sm font-semibold rounded-full border border-blue-100">
                    Live Edit Mode
                </div>
            </motion.div>
            
            <div className="bg-white rounded-3xl shadow-sm border border-slate-200 overflow-hidden min-h-[500px]">
                <div className="p-6 md:p-8">
                    <AnimatePresence mode="wait">
                        <motion.div
                            key={activeTab}
                            initial={{ opacity: 0, y: 10, filter: 'blur(5px)' }}
                            animate={{ opacity: 1, y: 0, filter: 'blur(0px)' }}
                            exit={{ opacity: 0, y: -10, filter: 'blur(5px)' }}
                            transition={{ type: "spring", stiffness: 300, damping: 30, mass: 0.8 }}
                            className="h-full"
                        >
                            {renderTabContent()}
                        </motion.div>
                    </AnimatePresence>
                </div>
            </div>
         </div>
      </div>
    </motion.div>
  );
};

// ... Sidebar, LoginView, SecuritySettings, WorkspaceTab remain similar, ListEditor updated below ...
// Re-exporting subcomponents to keep file self-contained as requested

const WorkspaceTab = () => {
    const [tasks, setTasks] = useState<TaskItem[]>([]);
    const [notes, setNotes] = useState<NoteItem[]>([]);
    const [newTaskText, setNewTaskText] = useState('');
    const [newNoteContent, setNewNoteContent] = useState('');
    const [activeSection, setActiveSection] = useState<'tasks' | 'notes'>('tasks');

    useEffect(() => {
        loadWorkspaceData();
    }, []);

    const loadWorkspaceData = async () => {
        const loadedTasks = await getAllTasks();
        const loadedNotes = await getAllNotes();
        setTasks(loadedTasks);
        setNotes(loadedNotes);
    };

    const handleAddTask = async (e: React.FormEvent) => {
        e.preventDefault();
        if (!newTaskText.trim()) return;
        
        const newTask: TaskItem = {
            id: Date.now().toString(),
            text: newTaskText,
            completed: false,
            createdAt: Date.now()
        };

        setTasks(prev => [newTask, ...prev]);
        setNewTaskText('');
        await saveTask(newTask);
    };

    const toggleTask = async (id: string) => {
        const task = tasks.find(t => t.id === id);
        if (task) {
            const updatedTask = { ...task, completed: !task.completed };
            setTasks(prev => prev.map(t => t.id === id ? updatedTask : t));
            await saveTask(updatedTask);
        }
    };

    const removeTask = async (id: string) => {
        setTasks(prev => prev.filter(t => t.id !== id));
        await deleteTask(id);
    };

    const handleAddNote = async () => {
        if (!newNoteContent.trim()) return;

        const newNote: NoteItem = {
            id: Date.now().toString(),
            content: newNoteContent,
            updatedAt: Date.now()
        };

        setNotes(prev => [newNote, ...prev]);
        setNewNoteContent('');
        await saveNote(newNote);
    };

    const removeNote = async (id: string) => {
        setNotes(prev => prev.filter(n => n.id !== id));
        await deleteNote(id);
    };

    return (
        <div className="space-y-6">
            <div className="flex gap-2 p-1 bg-slate-100 rounded-xl w-fit">
                <button 
                    onClick={() => setActiveSection('tasks')}
                    className={`px-4 py-2 rounded-lg text-sm font-semibold transition-all ${activeSection === 'tasks' ? 'bg-white text-blue-600 shadow-sm' : 'text-slate-500 hover:text-slate-700'}`}
                >
                    Tasks ({tasks.filter(t => !t.completed).length})
                </button>
                <button 
                    onClick={() => setActiveSection('notes')}
                    className={`px-4 py-2 rounded-lg text-sm font-semibold transition-all ${activeSection === 'notes' ? 'bg-white text-blue-600 shadow-sm' : 'text-slate-500 hover:text-slate-700'}`}
                >
                    Notes ({notes.length})
                </button>
            </div>

            {activeSection === 'tasks' ? (
                <div className="space-y-4">
                    <form onSubmit={handleAddTask} className="flex gap-2">
                        <input 
                            type="text" 
                            value={newTaskText}
                            onChange={(e) => setNewTaskText(e.target.value)}
                            placeholder="Add a new task..."
                            className="flex-1 px-4 py-3 bg-slate-50 border border-slate-200 rounded-xl focus:ring-2 focus:ring-blue-500/20 focus:border-blue-500 outline-none"
                        />
                        <button 
                            type="submit"
                            className="px-6 py-3 bg-blue-600 text-white font-bold rounded-xl hover:bg-blue-700 transition-colors"
                        >
                            <Plus size={20} />
                        </button>
                    </form>

                    <div className="space-y-2 max-h-[400px] overflow-y-auto pr-2">
                        <AnimatePresence>
                            {tasks.length === 0 && (
                                <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="text-center py-10 text-slate-400">
                                    <CheckSquare size={48} className="mx-auto mb-2 opacity-50" />
                                    <p>No tasks yet. Add one above!</p>
                                </motion.div>
                            )}
                            {tasks.map((task) => (
                                <motion.div 
                                    key={task.id}
                                    layout
                                    initial={{ opacity: 0, y: 10 }}
                                    animate={{ opacity: 1, y: 0 }}
                                    exit={{ opacity: 0, x: -10 }}
                                    className={`p-4 rounded-xl border flex items-center justify-between group transition-all ${task.completed ? 'bg-slate-50 border-slate-100 opacity-75' : 'bg-white border-slate-200 shadow-sm'}`}
                                >
                                    <div className="flex items-center gap-3 overflow-hidden">
                                        <button 
                                            onClick={() => toggleTask(task.id)}
                                            className={`w-6 h-6 rounded-lg border-2 flex items-center justify-center transition-colors ${task.completed ? 'bg-green-500 border-green-500 text-white' : 'border-slate-300 text-transparent hover:border-blue-400'}`}
                                        >
                                            <Check size={14} />
                                        </button>
                                        <span className={`truncate transition-all ${task.completed ? 'line-through text-slate-400' : 'text-slate-700 font-medium'}`}>{task.text}</span>
                                    </div>
                                    <button 
                                        onClick={() => removeTask(task.id)}
                                        className="p-2 text-slate-300 hover:text-red-500 hover:bg-red-50 rounded-lg transition-colors opacity-0 group-hover:opacity-100"
                                    >
                                        <Trash2 size={16} />
                                    </button>
                                </motion.div>
                            ))}
                        </AnimatePresence>
                    </div>
                </div>
            ) : (
                <div className="space-y-4">
                    <div className="bg-slate-50 border border-slate-200 rounded-xl p-4">
                        <textarea 
                            value={newNoteContent}
                            onChange={(e) => setNewNoteContent(e.target.value)}
                            placeholder="Write a note..."
                            className="w-full bg-transparent border-none outline-none resize-none h-24 mb-2"
                        />
                        <div className="flex justify-end">
                            <button 
                                onClick={handleAddNote}
                                disabled={!newNoteContent.trim()}
                                className="px-4 py-2 bg-blue-600 text-white rounded-lg text-sm font-semibold hover:bg-blue-700 disabled:opacity-50 disabled:cursor-not-allowed transition-colors"
                            >
                                Save Note
                            </button>
                        </div>
                    </div>

                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 max-h-[400px] overflow-y-auto pr-2">
                        {notes.length === 0 && (
                             <div className="col-span-full text-center py-10 text-slate-400">
                                <StickyNote size={48} className="mx-auto mb-2 opacity-50" />
                                <p>No notes saved.</p>
                            </div>
                        )}
                        {notes.map((note) => (
                            <motion.div 
                                key={note.id}
                                layout
                                initial={{ opacity: 0, scale: 0.9 }}
                                animate={{ opacity: 1, scale: 1 }}
                                className="bg-yellow-50 border border-yellow-100 p-4 rounded-xl shadow-sm relative group hover:shadow-md transition-shadow"
                            >
                                <p className="text-slate-700 text-sm whitespace-pre-wrap mb-6">{note.content}</p>
                                <div className="absolute bottom-3 right-3 flex items-center gap-2">
                                     <span className="text-[10px] text-slate-400">
                                        {new Date(note.updatedAt).toLocaleDateString()}
                                     </span>
                                    <button 
                                        onClick={() => removeNote(note.id)}
                                        className="p-1.5 text-slate-400 hover:text-red-500 hover:bg-red-50 rounded-lg transition-colors"
                                    >
                                        <Trash2 size={14} />
                                    </button>
                                </div>
                            </motion.div>
                        ))}
                    </div>
                </div>
            )}
        </div>
    );
};

const SecuritySettings = ({ currentCredentials, onUpdate }: any) => {
    const [formData, setFormData] = useState({
        currentPassword: '',
        newUsername: currentCredentials.username,
        newPassword: '',
        confirmPassword: ''
    });
    const [showPassword, setShowPassword] = useState({ current: false, new: false });
    const [status, setStatus] = useState({ type: '', message: '' });

    const handleSubmit = (e: React.FormEvent) => {
        e.preventDefault();
        
        if (formData.currentPassword !== currentCredentials.password) {
            setStatus({ type: 'error', message: 'Current password is incorrect.' });
            return;
        }
        
        if (formData.newPassword && formData.newPassword !== formData.confirmPassword) {
            setStatus({ type: 'error', message: 'New passwords do not match.' });
            return;
        }

        if (formData.newPassword && formData.newPassword.length < 6) {
             setStatus({ type: 'error', message: 'Password must be at least 6 characters.' });
             return;
        }

        const newCreds = {
            username: formData.newUsername,
            password: formData.newPassword || currentCredentials.password
        };

        onUpdate(newCreds);
        setStatus({ type: 'success', message: 'Credentials updated successfully!' });
        setFormData(prev => ({ ...prev, currentPassword: '', newPassword: '', confirmPassword: '' }));
        
        setTimeout(() => setStatus({ type: '', message: '' }), 3000);
    };

    return (
        <div className="max-w-2xl mx-auto space-y-8">
            <div className="mb-6 pb-6 border-b border-slate-100">
                <div className="flex items-center gap-4 text-blue-600 mb-4 bg-blue-50 p-4 rounded-xl">
                    <Shield size={32} />
                    <div>
                        <h3 className="font-bold text-lg text-slate-900">Admin Security</h3>
                        <p className="text-sm text-slate-600">Update your username and password to secure your portfolio admin panel.</p>
                    </div>
                </div>
            </div>

            <form onSubmit={handleSubmit} className="space-y-6">
                 {/* Verify Current Password */}
                 <div className="p-6 bg-slate-50 border border-slate-200 rounded-2xl">
                     <h4 className="font-semibold text-slate-800 mb-4 flex items-center gap-2">
                         <Lock size={18} className="text-slate-400" /> Verification
                     </h4>
                     <div>
                        <label className="block text-xs font-bold uppercase tracking-wider text-slate-400 mb-1.5 ml-1">Current Password</label>
                        <div className="relative group">
                            <input 
                                type={showPassword.current ? "text" : "password"}
                                value={formData.currentPassword} 
                                onChange={(e) => setFormData({...formData, currentPassword: e.target.value})}
                                required
                                className="w-full px-4 py-3 bg-white border border-slate-200 rounded-xl focus:ring-2 focus:ring-blue-500/20 focus:border-blue-500 outline-none transition-all"
                                placeholder="Enter current password"
                            />
                            <button 
                                type="button"
                                onClick={() => setShowPassword({...showPassword, current: !showPassword.current})}
                                className="absolute right-4 top-1/2 -translate-y-1/2 text-slate-400 hover:text-slate-600"
                            >
                                {showPassword.current ? <EyeOff size={18} /> : <Eye size={18} />}
                            </button>
                        </div>
                    </div>
                 </div>

                 {/* New Credentials */}
                 <div className="space-y-6 p-6 border border-slate-100 rounded-2xl">
                    <h4 className="font-semibold text-slate-800 mb-2 flex items-center gap-2">
                        <Key size={18} className="text-slate-400" /> New Credentials
                    </h4>
                    
                    <div>
                        <label className="block text-xs font-bold uppercase tracking-wider text-slate-400 mb-1.5 ml-1">Username</label>
                        <input 
                            type="text" 
                            value={formData.newUsername} 
                            onChange={(e) => setFormData({...formData, newUsername: e.target.value})}
                            required
                            className="w-full px-4 py-3 bg-slate-50 border border-slate-200 rounded-xl focus:ring-2 focus:ring-blue-500/20 focus:border-blue-500 outline-none transition-all"
                        />
                    </div>

                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                        <div>
                            <label className="block text-xs font-bold uppercase tracking-wider text-slate-400 mb-1.5 ml-1">New Password</label>
                            <div className="relative group">
                                <input 
                                    type={showPassword.new ? "text" : "password"}
                                    value={formData.newPassword} 
                                    onChange={(e) => setFormData({...formData, newPassword: e.target.value})}
                                    className="w-full px-4 py-3 bg-slate-50 border border-slate-200 rounded-xl focus:ring-2 focus:ring-blue-500/20 focus:border-blue-500 outline-none transition-all"
                                    placeholder="Leave empty to keep current"
                                />
                                <button 
                                    type="button"
                                    onClick={() => setShowPassword({...showPassword, new: !showPassword.new})}
                                    className="absolute right-4 top-1/2 -translate-y-1/2 text-slate-400 hover:text-slate-600"
                                >
                                    {showPassword.new ? <EyeOff size={18} /> : <Eye size={18} />}
                                </button>
                            </div>
                        </div>
                        <div>
                            <label className="block text-xs font-bold uppercase tracking-wider text-slate-400 mb-1.5 ml-1">Confirm Password</label>
                            <input 
                                type={showPassword.new ? "text" : "password"}
                                value={formData.confirmPassword} 
                                onChange={(e) => setFormData({...formData, confirmPassword: e.target.value})}
                                className="w-full px-4 py-3 bg-slate-50 border border-slate-200 rounded-xl focus:ring-2 focus:ring-blue-500/20 focus:border-blue-500 outline-none transition-all"
                                placeholder="Repeat new password"
                            />
                        </div>
                    </div>
                 </div>

                 {/* Status Messages */}
                 <AnimatePresence>
                     {status.message && (
                         <motion.div
                            initial={{ opacity: 0, height: 0 }}
                            animate={{ opacity: 1, height: 'auto' }}
                            exit={{ opacity: 0, height: 0 }}
                            className={`p-4 rounded-xl flex items-center gap-3 ${
                                status.type === 'error' 
                                    ? 'bg-red-50 text-red-600 border border-red-100' 
                                    : 'bg-green-50 text-green-600 border border-green-100'
                            }`}
                         >
                            {status.type === 'error' ? <X size={20} /> : <Check size={20} />}
                            <span className="font-medium">{status.message}</span>
                         </motion.div>
                     )}
                 </AnimatePresence>

                 <div className="pt-2">
                     <button
                        type="submit"
                        className="w-full py-4 bg-slate-900 text-white font-bold rounded-xl hover:bg-slate-800 transition-colors shadow-lg shadow-slate-900/10 flex items-center justify-center gap-2"
                     >
                         <Save size={18} /> Update Credentials
                     </button>
                 </div>
            </form>
        </div>
    );
};

const Sidebar = ({ activeTab, setActiveTab, onClose, handleSave, isSaving, saveSuccess }: {
  activeTab: TabId;
  setActiveTab: (id: TabId) => void;
  onClose: () => void;
  handleSave: () => void;
  isSaving: boolean;
  saveSuccess: boolean;
}) => (
    <motion.div 
        initial={{ x: -20, opacity: 0 }}
        animate={{ x: 0, opacity: 1 }}
        transition={{ duration: 0.5, ease: "easeOut" }}
        className="w-full md:w-72 bg-slate-900 text-slate-300 flex-none flex flex-col shadow-2xl z-20 relative overflow-hidden"
    >
        <div className="absolute top-0 left-0 w-full h-full overflow-hidden pointer-events-none opacity-10">
            <div className="absolute top-[-20%] left-[-20%] w-[300px] h-[300px] bg-blue-500 rounded-full blur-[80px]" />
            <div className="absolute bottom-[-10%] right-[-10%] w-[200px] h-[200px] bg-teal-500 rounded-full blur-[60px]" />
        </div>

        <div className="p-6 border-b border-slate-800/60 backdrop-blur-sm relative z-10 flex items-center justify-between">
           <div className="flex items-center gap-3">
             <div className="p-2 bg-blue-500/20 rounded-lg text-blue-400">
                <Sparkles size={20} />
             </div>
             <div>
                 <h3 className="font-bold text-white leading-tight">Admin Panel</h3>
                 <p className="text-xs text-slate-500">Portfolio Manager</p>
             </div>
           </div>
           <button onClick={onClose} className="md:hidden p-2 bg-slate-800 hover:bg-slate-700 rounded-lg text-white transition-colors">
             <X size={18} />
           </button>
        </div>
        
        <nav className="flex-1 p-4 space-y-2 overflow-x-auto md:overflow-y-auto flex md:flex-col gap-2 md:gap-0 no-scrollbar relative z-10">
          {TABS.map((tab) => (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id)}
              className={`relative w-full flex items-center gap-3 px-4 py-3.5 rounded-xl transition-all whitespace-nowrap outline-none group ${
                activeTab === tab.id ? 'text-white' : 'text-slate-400 hover:text-white'
              }`}
            >
              {activeTab === tab.id && (
                <motion.div
                  layoutId="activeTabBackground"
                  className="absolute inset-0 bg-blue-600 rounded-xl shadow-lg shadow-blue-900/40"
                  initial={false}
                  transition={{ type: "spring", stiffness: 300, damping: 30 }}
                />
              )}
              <span className="relative z-10 flex items-center gap-3">
                  <tab.icon size={20} className={`transition-transform duration-300 ${activeTab === tab.id ? 'scale-110' : 'group-hover:scale-110'}`} />
                  <span className="font-medium">{tab.label}</span>
              </span>
              {activeTab === tab.id && (
                 <motion.div 
                    layoutId="activeTabIndicator"
                    className="ml-auto w-1.5 h-1.5 bg-white rounded-full relative z-10"
                 />
              )}
            </button>
          ))}
        </nav>

        <div className="p-4 border-t border-slate-800/60 bg-slate-900/50 backdrop-blur-sm space-y-3 relative z-10">
            <motion.button 
                whileHover={{ scale: 1.02 }}
                whileTap={{ scale: 0.98 }}
                onClick={handleSave}
                disabled={isSaving}
                className={`w-full py-3.5 font-bold rounded-xl relative overflow-hidden transition-all shadow-lg ${
                    saveSuccess 
                        ? 'bg-green-500 hover:bg-green-600 text-white shadow-green-900/20' 
                        : 'bg-gradient-to-r from-blue-500 to-teal-500 hover:from-blue-600 hover:to-teal-600 text-white shadow-blue-900/20'
                }`}
            >
                <AnimatePresence mode="wait" initial={false}>
                    {isSaving ? (
                        <motion.span 
                            key="saving"
                            initial={{ opacity: 0, y: 20 }}
                            animate={{ opacity: 1, y: 0 }}
                            exit={{ opacity: 0, y: -20 }}
                            transition={{ duration: 0.2 }}
                            className="flex items-center justify-center gap-2"
                        >
                            <Loader2 size={20} className="animate-spin" />
                            Saving...
                        </motion.span>
                    ) : saveSuccess ? (
                        <motion.span 
                             key="success"
                             initial={{ opacity: 0, y: 20 }}
                             animate={{ opacity: 1, y: 0 }}
                             exit={{ opacity: 0, y: -20 }}
                             transition={{ duration: 0.2 }}
                             className="flex items-center justify-center gap-2"
                        >
                            <Check size={20} /> Saved!
                        </motion.span>
                    ) : (
                        <motion.span 
                             key="idle"
                             initial={{ opacity: 0, y: 20 }}
                             animate={{ opacity: 1, y: 0 }}
                             exit={{ opacity: 0, y: -20 }}
                             transition={{ duration: 0.2 }}
                             className="flex items-center justify-center gap-2"
                        >
                            <Save size={20} /> Save Changes
                        </motion.span>
                    )}
                </AnimatePresence>
            </motion.button>
             <button 
                onClick={onClose}
                className="w-full py-2.5 border border-slate-700 hover:bg-slate-800 text-slate-400 hover:text-white rounded-xl text-sm transition-colors flex items-center justify-center gap-2"
            >
                <LogOut size={16} /> Exit
            </button>
        </div>
    </motion.div>
);

const LoginView = ({ username, setUsername, password, setPassword, handleLogin, error, onClose }: any) => (
    <div className="fixed inset-0 z-[100] flex items-center justify-center p-4">
    <motion.div 
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        exit={{ opacity: 0 }}
        className="absolute inset-0 bg-slate-900/60 backdrop-blur-md"
    />
    
    <motion.div 
      initial={{ scale: 0.9, opacity: 0, y: 20 }}
      animate={{ scale: 1, opacity: 1, y: 0 }}
      exit={{ scale: 0.9, opacity: 0, y: -20 }}
      transition={{ type: "spring", duration: 0.5, bounce: 0.3 }}
      className="bg-white/90 backdrop-blur-xl rounded-3xl p-8 w-full max-w-md shadow-2xl relative z-10 border border-white/20"
      id="login-form"
    >
      <div className="flex justify-center mb-8">
        <motion.div 
            initial={{ rotate: -180, scale: 0 }}
            animate={{ rotate: 0, scale: 1 }}
            transition={{ type: "spring", delay: 0.2 }}
            className="p-5 bg-gradient-to-br from-blue-500 to-blue-600 rounded-2xl text-white shadow-lg shadow-blue-500/30"
        >
          <Lock size={32} />
        </motion.div>
      </div>
      
      <div className="text-center mb-8">
          <h2 className="text-2xl font-bold text-slate-800">Welcome Back</h2>
          <p className="text-slate-500 text-sm mt-1">Please enter your credentials to access the admin panel.</p>
      </div>

      <form onSubmit={handleLogin} className="space-y-5">
        <div className="space-y-4">
            <div className="relative group">
                <User className="absolute left-4 top-3.5 text-slate-400 group-focus-within:text-blue-500 transition-colors" size={18} />
                <input 
                    type="text" 
                    value={username}
                    onChange={(e) => setUsername(e.target.value)}
                    className="w-full pl-12 pr-4 py-3 bg-slate-50 border border-slate-200 rounded-xl focus:ring-2 focus:ring-blue-500/20 focus:border-blue-500 outline-none transition-all"
                    placeholder="Username"
                    autoFocus
                />
            </div>
            <div className="relative group">
                <Lock className="absolute left-4 top-3.5 text-slate-400 group-focus-within:text-blue-500 transition-colors" size={18} />
                <input 
                    type="password" 
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                    className="w-full pl-12 pr-4 py-3 bg-slate-50 border border-slate-200 rounded-xl focus:ring-2 focus:ring-blue-500/20 focus:border-blue-500 outline-none transition-all"
                    placeholder="Password"
                />
            </div>
        </div>

        {error && (
            <motion.div 
                initial={{ opacity: 0, height: 0 }} 
                animate={{ opacity: 1, height: 'auto' }}
                className="text-red-500 text-sm text-center bg-red-50 py-2 rounded-lg"
            >
                {error}
            </motion.div>
        )}

        <div className="flex gap-3 pt-2">
           <motion.button 
            whileHover={{ scale: 1.02 }}
            whileTap={{ scale: 0.98 }}
            type="button" 
            onClick={onClose}
            className="flex-1 px-4 py-3 border border-slate-200 text-slate-600 rounded-xl hover:bg-slate-50 transition-colors font-medium"
          >
            Cancel
          </motion.button>
          <motion.button 
            whileHover={{ scale: 1.02, boxShadow: "0 10px 25px -5px rgba(37, 99, 235, 0.4)" }}
            whileTap={{ scale: 0.98 }}
            type="submit" 
            className="flex-1 px-4 py-3 bg-gradient-to-r from-blue-600 to-blue-700 text-white rounded-xl hover:from-blue-700 hover:to-blue-800 transition-all font-semibold shadow-lg shadow-blue-500/20"
          >
            Login
          </motion.button>
        </div>
      </form>
    </motion.div>
  </div>
);

const AnimatedField = ({ label, value, onChange, fullWidth = false, delay = 0 }: { label: string, value: string, onChange: (v: string) => void, fullWidth?: boolean, delay?: number }) => (
    <motion.div 
        initial={{ opacity: 0, y: 10 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.3, delay }}
        className={fullWidth ? 'col-span-1 md:col-span-2' : ''}
    >
        <label className="block text-xs font-bold uppercase tracking-wider text-slate-400 mb-1.5 ml-1">{label}</label>
        <input 
            type="text" 
            value={value} 
            onChange={(e) => onChange(e.target.value)}
            className="w-full px-4 py-3 bg-slate-50 border border-slate-200 rounded-xl focus:ring-2 focus:ring-blue-500/20 focus:border-blue-500 outline-none transition-all hover:border-blue-300"
        />
    </motion.div>
);

const Field = ({ label, value, onChange, fullWidth = false }: { label: string, value: string, onChange: (v: string) => void, fullWidth?: boolean }) => (
    <div className={fullWidth ? 'col-span-1 md:col-span-2' : ''}>
        <label className="block text-xs font-bold uppercase tracking-wider text-slate-400 mb-1.5">{label}</label>
        <input 
            type="text" 
            value={value} 
            onChange={(e) => onChange(e.target.value)}
            className="w-full px-4 py-3 bg-slate-50 border border-slate-200 rounded-xl focus:ring-2 focus:ring-blue-500/20 focus:border-blue-500 outline-none transition-all"
        />
    </div>
);

interface Identifiable {
  id?: string;
  [key: string]: any;
}

interface ListEditorProps<T extends Identifiable> {
    items: T[];
    onUpdate: (items: T[]) => void;
    renderItem: (item: T, onChange: (updated: T) => void) => React.ReactNode;
    newItem: T;
}

function ListEditor<T extends Identifiable>({ items, onUpdate, renderItem, newItem }: ListEditorProps<T>) {
    const handleChange = (index: number, updatedItem: T) => {
        const newItems = [...items];
        newItems[index] = updatedItem;
        onUpdate(newItems);
    };

    const handleDelete = (index: number) => {
        const newItems = items.filter((_, i) => i !== index);
        onUpdate(newItems);
    };

    const handleAdd = () => {
        // Ensure new item has a unique ID if not provided in the template
        const itemToAdd = { ...newItem };
        if (!itemToAdd.id) {
            itemToAdd.id = Date.now().toString();
        }
        onUpdate([...items, itemToAdd]);
    };

    return (
        <div className="space-y-4">
             <AnimatePresence initial={false} mode="popLayout">
                {items.map((item, index) => (
                    <motion.div 
                        key={item.id || index} 
                        layout
                        initial={{ opacity: 0, scale: 0.9, y: 20 }}
                        animate={{ opacity: 1, scale: 1, y: 0 }}
                        exit={{ opacity: 0, scale: 0.9, transition: { duration: 0.2 } }}
                        className="p-6 bg-white border border-slate-200 rounded-2xl relative group hover:border-blue-300 hover:shadow-md transition-all"
                    >
                        <motion.button 
                            whileHover={{ scale: 1.1, backgroundColor: "#fee2e2", color: "#ef4444" }}
                            whileTap={{ scale: 0.9 }}
                            onClick={() => handleDelete(index)}
                            className="absolute top-4 right-4 p-2 text-slate-300 bg-slate-50 border border-slate-100 rounded-lg transition-colors z-10"
                            title="Delete Item"
                        >
                            <Trash2 size={18} />
                        </motion.button>
                        <div className="pr-12">
                            {renderItem(item, (updated) => handleChange(index, updated))}
                        </div>
                    </motion.div>
                ))}
            </AnimatePresence>
            
            <motion.button 
                layout
                whileHover={{ scale: 1.01, backgroundColor: "#f0f9ff", borderColor: "#60a5fa", color: "#2563eb" }}
                whileTap={{ scale: 0.99 }}
                onClick={handleAdd}
                className="w-full py-5 border-2 border-dashed border-slate-200 text-slate-400 rounded-2xl transition-all flex items-center justify-center gap-2 font-bold group"
            >
                <div className="p-1 bg-slate-100 rounded-full group-hover:bg-blue-200 transition-colors">
                    <Plus size={20} />
                </div>
                Add New Item
            </motion.button>
        </div>
    );
}

export default AdminPanel;
