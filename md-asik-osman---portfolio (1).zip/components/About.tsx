
import React from 'react';
import Section from './Section';
import { motion } from 'framer-motion';
import { ResumeData } from '../types';
import { User } from 'lucide-react';

interface AboutProps {
  data: ResumeData;
}

const About: React.FC<AboutProps> = ({ data }) => {
  return (
    <Section id="about" className="bg-white relative overflow-hidden">
      <div className="flex flex-col md:flex-row items-center gap-12 relative z-10">
        <motion.div 
          initial={{ opacity: 0, x: -30 }}
          whileInView={{ opacity: 1, x: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6 }}
          className="w-full md:w-5/12 flex justify-center"
        >
            <div className="relative group">
                <div className="absolute inset-0 bg-gradient-to-tr from-blue-600 to-teal-400 rounded-[2rem] rotate-6 group-hover:rotate-3 transition-transform duration-500 opacity-20 blur-xl"></div>
                <div className="relative w-64 h-80 md:w-80 md:h-96 rounded-[2rem] overflow-hidden border-4 border-white shadow-2xl bg-slate-100 flex items-center justify-center">
                    {data.profileImage ? (
                        <img 
                        src={data.profileImage} 
                        alt={data.name} 
                        className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-105"
                        />
                    ) : (
                        <User size={80} className="text-slate-300" />
                    )}
                </div>
            </div>
        </motion.div>

        <motion.div 
          initial={{ opacity: 0, x: 30 }}
          whileInView={{ opacity: 1, x: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6, delay: 0.2 }}
          className="w-full md:w-7/12"
        >
          <h2 className="text-3xl md:text-4xl font-bold text-slate-900 mb-6 flex items-center gap-4">
             <span className="w-12 h-1.5 bg-blue-600 block rounded-full"></span>
             About Me
          </h2>
          <div className="prose prose-lg text-slate-600 leading-relaxed mb-8">
            <p className="whitespace-pre-line">
              {data.summary || "I am a passionate professional dedicated to delivering high-quality results. With a strong background in my field, I strive to help clients achieve their goals through expertise and innovation."}
            </p>
          </div>
          
          <div className="flex flex-wrap gap-4">
              <div className="px-6 py-4 bg-slate-50 rounded-2xl border border-slate-100 flex-1 min-w-[140px] text-center md:text-left">
                  <span className="block text-3xl font-bold text-blue-600 mb-1">{new Date().getFullYear() - 2017}+</span>
                  <span className="text-sm text-slate-500 font-medium">Years Experience</span>
              </div>
              <div className="px-6 py-4 bg-slate-50 rounded-2xl border border-slate-100 flex-1 min-w-[140px] text-center md:text-left">
                  <span className="block text-3xl font-bold text-teal-500 mb-1">{data.projects.length}+</span>
                  <span className="text-sm text-slate-500 font-medium">Projects Completed</span>
              </div>
              <div className="px-6 py-4 bg-slate-50 rounded-2xl border border-slate-100 flex-1 min-w-[140px] text-center md:text-left">
                  <span className="block text-3xl font-bold text-purple-500 mb-1">{data.certifications.length}</span>
                  <span className="text-sm text-slate-500 font-medium">Certifications</span>
              </div>
          </div>
        </motion.div>
      </div>
    </Section>
  );
};

export default About;
