
import React from 'react';
import Section from './Section';
import { Mail, Phone, Linkedin, MapPin } from 'lucide-react';
import { ResumeData } from '../types';
import { motion } from 'framer-motion';

interface ContactProps {
    data: ResumeData;
}

const Contact: React.FC<ContactProps> = ({ data }) => {
  return (
    <footer id="contact" className="bg-slate-900 text-slate-300 py-16">
      <div className="max-w-7xl mx-auto px-6 md:px-12 grid grid-cols-1 md:grid-cols-2 gap-12">
        <motion.div
            initial={{ opacity: 0, x: -20 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.5 }}
        >
            <h2 className="text-3xl font-bold text-white mb-6">Let's Work Together</h2>
            <p className="text-slate-400 mb-8 max-w-md">
                I am ready to help your business grow with professional bookkeeping and accounting services. Reach out today for a consultation.
            </p>
             <div className="flex gap-4">
                 <a 
                    href={`https://${data.contact.linkedin}`} 
                    target="_blank" 
                    rel="noreferrer"
                    className="p-3 bg-slate-800 hover:bg-blue-600 rounded-full transition-colors"
                    aria-label="LinkedIn"
                 >
                     <Linkedin size={24} />
                 </a>
                 <a 
                    href={`mailto:${data.contact.email}`} 
                    className="p-3 bg-slate-800 hover:bg-teal-600 rounded-full transition-colors"
                    aria-label="Email"
                 >
                     <Mail size={24} />
                 </a>
            </div>
        </motion.div>

        <div className="space-y-6">
            <div className="flex items-center gap-4 p-4 bg-slate-800/50 rounded-lg hover:bg-slate-800 transition-colors">
                <div className="p-3 bg-blue-600/20 text-blue-400 rounded-full">
                    <Phone size={24} />
                </div>
                <div>
                    <p className="text-sm text-slate-500">Call Me</p>
                    <p className="text-lg font-semibold text-white">{data.contact.phone}</p>
                </div>
            </div>

             <div className="flex items-center gap-4 p-4 bg-slate-800/50 rounded-lg hover:bg-slate-800 transition-colors">
                <div className="p-3 bg-teal-600/20 text-teal-400 rounded-full">
                    <Mail size={24} />
                </div>
                <div>
                    <p className="text-sm text-slate-500">Email Me</p>
                    <p className="text-lg font-semibold text-white break-all">{data.contact.email}</p>
                </div>
            </div>

            <div className="flex items-center gap-4 p-4 bg-slate-800/50 rounded-lg hover:bg-slate-800 transition-colors">
                <div className="p-3 bg-purple-600/20 text-purple-400 rounded-full">
                    <MapPin size={24} />
                </div>
                <div>
                    <p className="text-sm text-slate-500">Location</p>
                    <p className="text-lg font-semibold text-white">{data.contact.location}</p>
                </div>
            </div>
        </div>
      </div>
      <div className="max-w-7xl mx-auto px-6 md:px-12 mt-16 pt-8 border-t border-slate-800 flex justify-between items-center text-sm text-slate-500">
        <p>© {new Date().getFullYear()} Md Asik Osman. All rights reserved.</p>
      </div>
    </footer>
  );
};

export default Contact;
