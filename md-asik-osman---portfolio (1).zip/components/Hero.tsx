
import React from 'react';
import { ResumeData } from '../types';
import { motion } from 'framer-motion';
import { Mail, Phone, MapPin, Linkedin, Download, Briefcase, User, MessageSquare } from 'lucide-react';

interface HeroProps {
  data: ResumeData;
  onOpenContact: () => void;
}

const Hero: React.FC<HeroProps> = ({ data, onOpenContact }) => {
  const scrollToAbout = () => {
    document.getElementById('about')?.scrollIntoView({ behavior: 'smooth' });
  };

  return (
    <div className="relative min-h-[90vh] flex items-center justify-center bg-slate-900 text-white overflow-hidden">
        {/* Abstract Background Shapes */}
        <div className="absolute inset-0 overflow-hidden opacity-20 pointer-events-none">
             <div className="absolute -top-[20%] -left-[10%] w-[50%] h-[50%] bg-blue-500 rounded-full blur-[100px]" />
             <div className="absolute bottom-[10%] right-[0%] w-[40%] h-[40%] bg-teal-500 rounded-full blur-[120px]" />
        </div>

      <div className="relative z-10 max-w-4xl mx-auto px-6 text-center">
        <motion.div
          initial={{ opacity: 0, scale: 0.9 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ duration: 0.8 }}
          className="mb-6 inline-block"
        >
             <span className="px-3 py-1 border border-blue-400/30 bg-blue-900/20 rounded-full text-blue-300 text-sm font-medium tracking-wide">
                PORTFOLIO
             </span>
        </motion.div>

        <motion.h1
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, delay: 0.1 }}
          className="text-4xl md:text-7xl font-bold mb-6 tracking-tight leading-tight"
        >
          Hello, I'm <br />
          <span className="bg-gradient-to-r from-blue-400 to-teal-300 gradient-text text-transparent">
            {data.name}
          </span>
        </motion.h1>

        <motion.p
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, delay: 0.2 }}
          className="text-xl md:text-2xl text-slate-300 mb-8 max-w-2xl mx-auto font-light"
        >
          {data.title}
        </motion.p>

        <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8, delay: 0.3 }}
            className="flex flex-wrap justify-center gap-4 text-slate-400 mb-10"
        >
            <div className="flex items-center gap-2">
                <MapPin size={18} className="text-blue-400" />
                <span>{data.contact.location}</span>
            </div>
             <div className="hidden md:block w-1 h-1 bg-slate-600 rounded-full self-center" />
             <a href={`mailto:${data.contact.email}`} className="flex items-center gap-2 hover:text-white transition-colors">
                <Mail size={18} className="text-blue-400" />
                <span>{data.contact.email}</span>
            </a>
            <div className="hidden md:block w-1 h-1 bg-slate-600 rounded-full self-center" />
             <a href={`tel:${data.contact.phone}`} className="flex items-center gap-2 hover:text-white transition-colors">
                <Phone size={18} className="text-blue-400" />
                <span>{data.contact.phone}</span>
            </a>
        </motion.div>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, delay: 0.4 }}
          className="flex flex-wrap justify-center gap-4 items-center"
        >
            <button 
                onClick={onOpenContact}
                className="px-8 py-3.5 bg-gradient-to-r from-blue-600 to-teal-500 hover:from-blue-700 hover:to-teal-600 text-white rounded-full font-bold transition-all shadow-lg hover:shadow-blue-500/40 transform hover:-translate-y-1 flex items-center gap-2 text-lg ring-4 ring-blue-500/20"
            >
                <Briefcase size={22} />
                Hire Me
            </button>

            <button 
                onClick={onOpenContact}
                className="px-8 py-3.5 bg-slate-800 hover:bg-slate-700 text-white rounded-full font-semibold transition-all shadow-lg hover:shadow-slate-700/50 transform hover:-translate-y-1 flex items-center gap-2"
            >
                <MessageSquare size={20} />
                Get in Touch
            </button>

            <button 
                onClick={scrollToAbout}
                className="px-8 py-3.5 bg-white text-slate-900 hover:bg-slate-100 rounded-full font-semibold transition-all shadow-lg hover:shadow-xl transform hover:-translate-y-1 flex items-center gap-2"
            >
                <User size={20} />
                About Me
            </button>

            <a 
                href={`https://${data.contact.linkedin}`} 
                target="_blank" 
                rel="noreferrer"
                className="px-4 py-3.5 border border-slate-700 hover:border-slate-500 text-slate-400 hover:text-white rounded-full font-medium transition-all flex items-center gap-2 hover:bg-slate-800"
                aria-label="LinkedIn"
            >
                <Linkedin size={20} />
            </a>
        </motion.div>
      </div>
    </div>
  );
};

export default Hero;
