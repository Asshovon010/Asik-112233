import { GoogleGenAI, Chat } from "@google/genai";

let chatSession: Chat | null = null;
let currentInstruction: string = "";

export const getChatSession = (systemInstruction: string): Chat => {
  // If session exists and instruction hasn't changed, return it
  if (chatSession && currentInstruction === systemInstruction) {
    return chatSession;
  }

  const apiKey = process.env.API_KEY;
  if (!apiKey) {
    console.warn("API_KEY is not set in process.env");
    throw new Error("API Key missing");
  }

  const ai = new GoogleGenAI({ apiKey });
  
  currentInstruction = systemInstruction;
  chatSession = ai.chats.create({
    model: 'gemini-3-flash-preview',
    config: {
      systemInstruction: systemInstruction,
    },
  });

  return chatSession;
};

export const sendMessageToGemini = async (message: string, systemInstruction: string): Promise<string> => {
  try {
    const chat = getChatSession(systemInstruction);
    const result = await chat.sendMessage({ message });
    return result.text || "I'm sorry, I couldn't generate a response.";
  } catch (error) {
    console.error("Error communicating with Gemini:", error);
    // Reset session on error to force recreation next time might help
    chatSession = null;
    return "Sorry, I'm having trouble connecting right now. Please try again later.";
  }
};