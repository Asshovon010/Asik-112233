import { openDB, DBSchema } from 'idb';
import { ResumeData } from '../types';

export interface NoteItem {
  id: string;
  content: string;
  updatedAt: number;
}

export interface TaskItem {
  id: string;
  text: string;
  completed: boolean;
  createdAt: number;
}

interface PortfolioDB extends DBSchema {
  'portfolio': {
    key: string;
    value: ResumeData;
  };
  'admin': {
    key: string;
    value: any;
  };
  'notes': {
    key: string;
    value: NoteItem;
  };
  'tasks': {
    key: string;
    value: TaskItem;
  };
}

const DB_NAME = 'portfolio-manager-db';
const DB_VERSION = 1;

const getDB = async () => {
  return openDB<PortfolioDB>(DB_NAME, DB_VERSION, {
    upgrade(db) {
      if (!db.objectStoreNames.contains('portfolio')) {
        db.createObjectStore('portfolio');
      }
      if (!db.objectStoreNames.contains('admin')) {
        db.createObjectStore('admin');
      }
      if (!db.objectStoreNames.contains('notes')) {
        db.createObjectStore('notes', { keyPath: 'id' });
      }
      if (!db.objectStoreNames.contains('tasks')) {
        db.createObjectStore('tasks', { keyPath: 'id' });
      }
    },
  });
};

// Resume Data
export const saveResumeData = async (data: ResumeData) => {
  const db = await getDB();
  await db.put('portfolio', data, 'main_data');
};

export const getResumeData = async (): Promise<ResumeData | undefined> => {
  const db = await getDB();
  return db.get('portfolio', 'main_data');
};

// Admin Credentials
export const saveAdminCredentials = async (creds: { username: string; password: string }) => {
  const db = await getDB();
  await db.put('admin', creds, 'credentials');
};

export const getAdminCredentials = async () => {
  const db = await getDB();
  return db.get('admin', 'credentials');
};

// Notes
export const saveNote = async (note: NoteItem) => {
  const db = await getDB();
  await db.put('notes', note);
};

export const deleteNote = async (id: string) => {
    const db = await getDB();
    await db.delete('notes', id);
};

export const getAllNotes = async () => {
  const db = await getDB();
  return db.getAll('notes');
};

// Tasks
export const saveTask = async (task: TaskItem) => {
  const db = await getDB();
  await db.put('tasks', task);
};

export const deleteTask = async (id: string) => {
    const db = await getDB();
    await db.delete('tasks', id);
};

export const getAllTasks = async () => {
  const db = await getDB();
  return db.getAll('tasks');
};